package Airport;

public enum Location {
	Jerusalem, Paris, NewYork, London, Rome, Barcelona, Madrid, Copenhagen, Helsinki, Bordeaux
}
